<?php 
if(substr($_SERVER["REQUEST_URI"], -10) == "config.php"){header("Location:./");}; 
$data['mikhmon'] = array ('1'=>'mikhmon<|<mauljasmay','mikhmon>|>hZKnpGJjaGY=');

$data['MLJ.NET'] = array ('1'=>'MLJ.NET!103.76.148.154:8738','MLJ.NET@|@testmlj','MLJ.NET#|#aWJibWJr','MLJ.NET%MLJ-Hotspot','MLJ.NET^mlj.me','MLJ.NET&Rp','MLJ.NET*60','MLJ.NET(4','MLJ.NET)','MLJ.NET=disable','MLJ.NET@!@enable');